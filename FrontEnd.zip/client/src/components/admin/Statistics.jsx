// src/components/admin/Statistics.jsx
import React from "react";

const Statistics = () => {
  return (
    <div className="admin-container">
      <h2>Statistics</h2>
      <p>View platform statistics here.</p>
    </div>
  );
};

export default Statistics;